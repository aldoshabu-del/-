концепция сайта Алхасты. Только для обсуждения.
Публично (можно давать всем):
Главный сайт:
https://aldoshabu-del.github.io/alkhasty/ → index.html

Полноэкранная карта:
https://aldoshabu-del.github.io/alkhasty/index-map.html

Страница «Инвесторам» (по ситуации):
https://aldoshabu-del.github.io/alkhasty/investors.html

Только для команды:
Редактор:
https://aldoshabu-del.github.io/alkhasty/editor.html
👉 не добавляем его в меню и не светим в интерфейсе
